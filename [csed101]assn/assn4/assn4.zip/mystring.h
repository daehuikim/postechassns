#ifndef MY_STRING_H
#define MY_STRING_H

int mystrlen(char *str); 
char *mystrcpy(char *toStr, char *fromStr); 
int mystrcmp(char *str1, char *str2); 
char *mystrcat(char *str1, char *str2);

#endif
