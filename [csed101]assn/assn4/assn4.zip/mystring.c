int mystrlen(char *str)
{
	// Insert your code 
}

char *mystrcpy(char *toStr, char *fromStr)
{
	// Insert your code 
}

int mystrcmp(char *str1, char *str2)
{
	// Insert your code 
}

char *mystrcat(char *str1, char *str2)
{
	// Insert your code 
}
